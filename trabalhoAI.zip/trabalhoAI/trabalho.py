#vcs devem trabalhar com a planilha do InfoPEN da seguinte forma:
#Apagar as colunas A, B, C, E, F, G, J e do 1.4 nivel em diante. OK
#Vcs devem normalizar a coluna referente ao nome do estabelecimento a fim de deixar somente com a categoria. Ai devem pintar esta coluna de uma cor, pois ela é referente a classe (rótulo)
#Depois vcs vão eliminar a linha 15 (caso já não tenha feita isto) Era a linha que tinha os hífens. OK
#Na sequência vcs devem utilizar uma ferramenta para análise exploratória de dados - pode ser R, Weka ou Pandas
#Devem fazer a distribuição de frequência das classes e indicar se vão fazer oversampling ou não e pq
#Devem verificar para cada coluna se há outliers
#Devem justificar se retiraram ou não registros ou se imputaram dados e pq.

import pandas as pd
import datetime as dt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import numpy as np

headers = ['Nome da unidade prisional:']
base = pd.read_csv("Bruto.csv",header=None, names=headers)
norm = StandardScaler()

x_train_ = np.array(base.iloc[:, 0:11])
y_train_ = np.array(base["Nome da unidade prisional:"])

#Separação de treino e validação

x_train: object
x_train,x_val,y_train,y_val = train_test_split(x_train_,y_train_)

#Carga do conjunto de teste

base_test = pd.read_csv("Bruto.csv", header=None, names=headers)


#Transformação dos atributos e da classe alvo em matrizes
X_test = np.array(base.iloc[:, 0:11])
y_test = np.array(base_test['Nome da unidade prisional:'])

# Criação do transformador para noramlização
from sklearn.preprocessing import StandardScaler

norm = StandardScaler()


print(x_train_[0],
      X_test[0],
      )
print(base.head(),
      base_test.head(),
      x_train[0],
      y_train[0],
      )


base.shape
base.info()
base.dtypes
base.describe()


print(base.info())

